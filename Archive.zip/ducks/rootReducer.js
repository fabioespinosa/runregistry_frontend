import { combineReducers } from 'redux';
import online from './online';

const rootReducer = combineReducers({
    online
});

export default rootReducer;
