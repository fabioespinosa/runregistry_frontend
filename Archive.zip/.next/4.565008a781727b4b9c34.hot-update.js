webpackHotUpdate(4,{

/***/ "./layout/page.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__ = __webpack_require__("./node_modules/styled-jsx/style.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react__ = __webpack_require__("./node_modules/react/cjs/react.development.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_head__ = __webpack_require__("./node_modules/next/head.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_next_head___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_next_head__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_next_router__ = __webpack_require__("./node_modules/next/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_next_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_next_router__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_nprogress__ = __webpack_require__("./node_modules/nprogress/nprogress.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_nprogress___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_nprogress__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_antd_dist_antd_min_css__ = __webpack_require__("./node_modules/antd/dist/antd.min.css");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_antd_dist_antd_min_css___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_antd_dist_antd_min_css__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_analytics__ = __webpack_require__("./services/analytics.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_ui_nav_Nav__ = __webpack_require__("./components/ui/nav/Nav.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_ui_theme__ = __webpack_require__("./components/ui/theme.js");
var _jsxFileName = "/Users/fabioespinosa/Desktop/runregistry/layout/page.js";


(function () {
  var enterModule = __webpack_require__("./node_modules/react-hot-loader/index.js").enterModule;

  enterModule && enterModule(module);
})();









/**
 * Starts nprogress (the 5px colored bar on top that appears progressing as route changes)
 * @param {*} url
 */

__WEBPACK_IMPORTED_MODULE_3_next_router___default.a.onRouteChangeStart = function (url) {
  return __WEBPACK_IMPORTED_MODULE_4_nprogress___default.a.start();
};

__WEBPACK_IMPORTED_MODULE_3_next_router___default.a.onRouteChangeComplete = function () {
  return __WEBPACK_IMPORTED_MODULE_4_nprogress___default.a.done();
};

__WEBPACK_IMPORTED_MODULE_3_next_router___default.a.onRouteChangeError = function () {
  return __WEBPACK_IMPORTED_MODULE_4_nprogress___default.a.done();
};
/**
 * This functional component is used for
 * @param {} props
 */


var Page = function Page(props) {
  return __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23
    },
    className: "jsx-684848878"
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2_next_head___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24
    }
  }, __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("link", {
    rel: "stylesheet",
    type: "text/css",
    href: "/static/nprogress.css",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    className: "jsx-684848878"
  }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("meta", {
    charSet: "utf-8",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30
    },
    className: "jsx-684848878"
  }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("meta", {
    name: "viewport",
    content: "width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 31
    },
    className: "jsx-684848878"
  }), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement("link", {
    rel: "stylesheet",
    href: "/_next/static/style.css",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35
    },
    className: "jsx-684848878"
  })), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_7__components_ui_nav_Nav__["a" /* default */], {
    router: props.router,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37
    }
  }, props.children), __WEBPACK_IMPORTED_MODULE_1_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_0_styled_jsx_style___default.a, {
    styleId: "684848878",
    css: ".properly_capitalized{text-transform:capitalize;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxheW91dC9wYWdlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXFDMkIsQUFHMkMsMEJBQzlCIiwiZmlsZSI6ImxheW91dC9wYWdlLmpzIiwic291cmNlUm9vdCI6Ii9Vc2Vycy9mYWJpb2VzcGlub3NhL0Rlc2t0b3AvcnVucmVnaXN0cnkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJztcbmltcG9ydCBSb3V0ZXIgZnJvbSAnbmV4dC9yb3V0ZXInO1xuaW1wb3J0IFByb2dyZXNzIGZyb20gJ25wcm9ncmVzcyc7XG5pbXBvcnQgc3R5bGVzaGVldCBmcm9tICdhbnRkL2Rpc3QvYW50ZC5taW4uY3NzJztcbmltcG9ydCB7IGluaXRHQSwgbG9nUGFnZVZpZXcgfSBmcm9tICcuLi9zZXJ2aWNlcy9hbmFseXRpY3MnO1xuaW1wb3J0IE5hdiBmcm9tICcuLy4uL2NvbXBvbmVudHMvdWkvbmF2L05hdic7XG5pbXBvcnQgeyBjb2xvcnMgfSBmcm9tICcuLi9jb21wb25lbnRzL3VpL3RoZW1lJztcblxuLyoqXG4gKiBTdGFydHMgbnByb2dyZXNzICh0aGUgNXB4IGNvbG9yZWQgYmFyIG9uIHRvcCB0aGF0IGFwcGVhcnMgcHJvZ3Jlc3NpbmcgYXMgcm91dGUgY2hhbmdlcylcbiAqIEBwYXJhbSB7Kn0gdXJsXG4gKi9cblJvdXRlci5vblJvdXRlQ2hhbmdlU3RhcnQgPSB1cmwgPT4gUHJvZ3Jlc3Muc3RhcnQoKTtcblJvdXRlci5vblJvdXRlQ2hhbmdlQ29tcGxldGUgPSAoKSA9PiBQcm9ncmVzcy5kb25lKCk7XG5Sb3V0ZXIub25Sb3V0ZUNoYW5nZUVycm9yID0gKCkgPT4gUHJvZ3Jlc3MuZG9uZSgpO1xuXG4vKipcbiAqIFRoaXMgZnVuY3Rpb25hbCBjb21wb25lbnQgaXMgdXNlZCBmb3JcbiAqIEBwYXJhbSB7fSBwcm9wc1xuICovXG5jb25zdCBQYWdlID0gcHJvcHMgPT4gKFxuICAgIDxkaXY+XG4gICAgICAgIDxIZWFkPlxuICAgICAgICAgICAgPGxpbmtcbiAgICAgICAgICAgICAgICByZWw9XCJzdHlsZXNoZWV0XCJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dC9jc3NcIlxuICAgICAgICAgICAgICAgIGhyZWY9XCIvc3RhdGljL25wcm9ncmVzcy5jc3NcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxtZXRhIGNoYXJTZXQ9XCJ1dGYtOFwiIC8+XG4gICAgICAgICAgICA8bWV0YVxuICAgICAgICAgICAgICAgIG5hbWU9XCJ2aWV3cG9ydFwiXG4gICAgICAgICAgICAgICAgY29udGVudD1cIndpZHRoPWRldmljZS13aWR0aCwgbWluaW11bS1zY2FsZT0xLjAsIG1heGltdW0tc2NhbGU9MS4wLCB1c2VyLXNjYWxhYmxlPW5vXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8bGluayByZWw9XCJzdHlsZXNoZWV0XCIgaHJlZj1cIi9fbmV4dC9zdGF0aWMvc3R5bGUuY3NzXCIgLz5cbiAgICAgICAgPC9IZWFkPlxuICAgICAgICA8TmF2IHJvdXRlcj17cHJvcHMucm91dGVyfT57cHJvcHMuY2hpbGRyZW59PC9OYXY+XG4gICAgICAgIDxzdHlsZSBqc3ggZ2xvYmFsPntgXG4gICAgICAgICAgICAucHJvcGVybHlfY2FwaXRhbGl6ZWQge1xuICAgICAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xuICAgICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgPC9kaXY+XG4pO1xuXG5leHBvcnQgZGVmYXVsdCBQYWdlO1xuIl19 */\n/*@ sourceURL=layout/page.js */"
  }));
};

var _default = Page;
/* harmony default export */ __webpack_exports__["a"] = (_default);
;

(function () {
  var reactHotLoader = __webpack_require__("./node_modules/react-hot-loader/index.js").default;

  var leaveModule = __webpack_require__("./node_modules/react-hot-loader/index.js").leaveModule;

  if (!reactHotLoader) {
    return;
  }

  reactHotLoader.register(Page, "Page", "/Users/fabioespinosa/Desktop/runregistry/layout/page.js");
  reactHotLoader.register(_default, "default", "/Users/fabioespinosa/Desktop/runregistry/layout/page.js");
  leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=4.565008a781727b4b9c34.hot-update.js.map