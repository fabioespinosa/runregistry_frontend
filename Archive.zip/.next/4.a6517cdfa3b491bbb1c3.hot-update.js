webpackHotUpdate(4,{

/***/ "./components/ui/nav/side/SideNav.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_antd_lib_icon_style_css__ = __webpack_require__("./node_modules/antd/lib/icon/style/css.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_antd_lib_icon_style_css___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_antd_lib_icon_style_css__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_antd_lib_icon__ = __webpack_require__("./node_modules/antd/lib/icon/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_antd_lib_icon___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_antd_lib_icon__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_antd_lib_menu_style_css__ = __webpack_require__("./node_modules/antd/lib/menu/style/css.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_antd_lib_menu_style_css___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_antd_lib_menu_style_css__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_antd_lib_menu__ = __webpack_require__("./node_modules/antd/lib/menu/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_antd_lib_layout_style_css__ = __webpack_require__("./node_modules/antd/lib/layout/style/css.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_antd_lib_layout_style_css___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_antd_lib_layout_style_css__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_antd_lib_layout__ = __webpack_require__("./node_modules/antd/lib/layout/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_antd_lib_layout___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_antd_lib_layout__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_react__ = __webpack_require__("./node_modules/react/cjs/react.development.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_next_router__ = __webpack_require__("./node_modules/next/router.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_next_router___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_next_router__);






var _jsxFileName = "/Users/fabioespinosa/Desktop/runregistry/components/ui/nav/side/SideNav.js";

(function () {
  var enterModule = __webpack_require__("./node_modules/react-hot-loader/index.js").enterModule;

  enterModule && enterModule(module);
})();

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }



var Sider = __WEBPACK_IMPORTED_MODULE_5_antd_lib_layout___default.a.Sider;
var SubMenu = __WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.SubMenu;

var SideNav =
/*#__PURE__*/
function (_Component) {
  _inherits(SideNav, _Component);

  function SideNav() {
    _classCallCheck(this, SideNav);

    return _possibleConstructorReturn(this, (SideNav.__proto__ || Object.getPrototypeOf(SideNav)).apply(this, arguments));
  }

  _createClass(SideNav, [{
    key: "onRouteChangeHandler",
    value: function onRouteChangeHandler(_ref) {
      var key = _ref.key,
          keyPath = _ref.keyPath;
      var _props$router$query = this.props.router.query,
          type = _props$router$query.type,
          section = _props$router$query.section,
          run_filter = _props$router$query.run_filter;

      if (key === 'lumisections') {
        __WEBPACK_IMPORTED_MODULE_7_next_router___default.a.push("/".concat(type, "?type=").concat(type, "&section=lumisections"), "/".concat(type, "/lumisections"));
      } else {
        __WEBPACK_IMPORTED_MODULE_7_next_router___default.a.push("/".concat(type, "?type=").concat(type, "&section=").concat(keyPath[1], "&run_filter=").concat(key), "/".concat(type, "/").concat(keyPath[1], "/").concat(key));
      }
    }
  }, {
    key: "render",
    value: function render() {
      console.log(__WEBPACK_IMPORTED_MODULE_7_next_router___default.a);
      var _props$router$query2 = this.props.router.query,
          type = _props$router$query2.type,
          section = _props$router$query2.section,
          run_filter = _props$router$query2.run_filter;
      var defaultSelectedKey = section === 'lumisections' ? 'lumisections' : run_filter;
      return __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5_antd_lib_layout___default.a, {
        hasSider: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 38
        }
      }, __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(Sider, {
        collapsible: true,
        width: 200,
        style: {
          background: '#fff'
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 39
        }
      }, __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a, {
        mode: "inline",
        onClick: this.onRouteChangeHandler.bind(this),
        defaultOpenKeys: [section],
        defaultSelectedKeys: [defaultSelectedKey],
        style: {
          height: '100%',
          borderRight: 0
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 40
        }
      }, __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(SubMenu, {
        key: "runs",
        title: __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement("span", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 50
          }
        }, __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_antd_lib_icon___default.a, {
          type: "rocket",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 51
          }
        }), "RUNS"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 47
        }
      }, __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "all",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56
        }
      }, "ALL"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "current",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 57
        }
      }, "CURRENT"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "selected",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 58
        }
      }, "SELECTED")), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "lumisections",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 60
        }
      }, __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement("span", {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 61
        }
      }, __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_antd_lib_icon___default.a, {
        type: "bulb",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 62
        }
      }), "LUMISECTIONS")), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(SubMenu, {
        key: "sub3",
        title: __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement("span", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 69
          }
        }, __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1_antd_lib_icon___default.a, {
          type: "laptop",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 70
          }
        }), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement("span", {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 71
          }
        }, "WORKSPACE")),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 66
        }
      }, __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "4",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 75
        }
      }, "GLOBAL"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "5",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 76
        }
      }, "BTAG"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "6",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 77
        }
      }, "CASTOR"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "7",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 78
        }
      }, "CSC"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "8",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 79
        }
      }, "CTPPS"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "9",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 80
        }
      }, "DT"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "10",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 81
        }
      }, "ECAL"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "11",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 82
        }
      }, "EGAMMA"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "12",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 83
        }
      }, "HCAL"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "13",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 84
        }
      }, "HLT"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "14",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 85
        }
      }, "JETMET"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "15",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 86
        }
      }, "L1T"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "16",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 87
        }
      }, "LUMI"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "17",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 88
        }
      }, "LUMI"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "18",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 89
        }
      }, "MUON"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "19",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 90
        }
      }, "RPC"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "20",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 91
        }
      }, "TAU"), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3_antd_lib_menu___default.a.Item, {
        key: "21",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 92
        }
      }, "TRACKER")))), __WEBPACK_IMPORTED_MODULE_6_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5_antd_lib_layout___default.a, {
        style: {
          padding: '0 24px 24px'
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 96
        }
      }, this.props.children));
    }
  }, {
    key: "__reactstandin__regenerateByEval",
    // @ts-ignore
    value: function __reactstandin__regenerateByEval(key, code) {
      // @ts-ignore
      this[key] = eval(code);
    }
  }]);

  return SideNav;
}(__WEBPACK_IMPORTED_MODULE_6_react__["Component"]);

var _default = SideNav;
/* harmony default export */ __webpack_exports__["a"] = (_default);
;

(function () {
  var reactHotLoader = __webpack_require__("./node_modules/react-hot-loader/index.js").default;

  var leaveModule = __webpack_require__("./node_modules/react-hot-loader/index.js").leaveModule;

  if (!reactHotLoader) {
    return;
  }

  reactHotLoader.register(Sider, "Sider", "/Users/fabioespinosa/Desktop/runregistry/components/ui/nav/side/SideNav.js");
  reactHotLoader.register(SubMenu, "SubMenu", "/Users/fabioespinosa/Desktop/runregistry/components/ui/nav/side/SideNav.js");
  reactHotLoader.register(SideNav, "SideNav", "/Users/fabioespinosa/Desktop/runregistry/components/ui/nav/side/SideNav.js");
  reactHotLoader.register(_default, "default", "/Users/fabioespinosa/Desktop/runregistry/components/ui/nav/side/SideNav.js");
  leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=4.a6517cdfa3b491bbb1c3.hot-update.js.map