import React, { Component } from 'react';

class Run extends Component {
    render() {
        return <div>This is a run</div>;
    }
}

export default Run;
